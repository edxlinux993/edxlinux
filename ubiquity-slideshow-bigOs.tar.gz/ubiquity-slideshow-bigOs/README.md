# Ubiquity Slideshow BigOs

Este repositório contém um pacote de slides para o instalador Ubiquity com temas relacionados ao BigOs.

## Instalação

Para instalar o slideshow, siga os passos abaixo:

1.   ** descompactar **  
   
   tar -vzxf ubiquity-slideshow-bigOs.tar.gz

depois so remover o arquivo compactado ubiquity-slideshow-bigOs.tar.gz

rm ubiquity-slideshow-bigOs.tar.gz 


atualizar cache

sudo update-ubiquity



